﻿Imports System.Runtime.InteropServices
Imports System.Text

Module Module_Watch_ArduinoIDE

    <DllImport("user32.dll", SetLastError:=True)> _
    Private Function GetForegroundWindow() As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Function GetWindowTextLength(ByVal hWnd As IntPtr) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> _
    Private Function GetWindowText(ByVal hWnd As IntPtr, ByVal lpString As StringBuilder, ByVal nMaxCount As Integer) As Integer
    End Function

    Private Function GetActiveWindowTitle() As String
        Dim handle As IntPtr = GetForegroundWindow()
        Dim length As Integer = GetWindowTextLength(handle)
        Dim title As New StringBuilder("", length + 1)
        GetWindowText(handle, title, title.Capacity)
        Return title.ToString()
    End Function

    ' ----------------------------------------------------- about 50 uS 
    Friend Function ArduinoIDE_HasFocus() As Boolean
        Dim s As String = GetActiveWindowTitle()
        Return s.StartsWith("Theremino_Tester_Sketch") And s.Contains(" | Arduino")
    End Function

End Module
