﻿Public Class Form1

    Friend EnlargedWidth As Int32 = Me.Width

    ' ===================================================================
    '  OPEN CLOSE FORM
    ' ===================================================================
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Text = AppTitleAndVersion()
        ToolTips_Init()
        ComboComPort_AddItems()
        Me.MinimumSize = New Size(0, Me.MinimumSize.Height)
        Load_INI()
        Update_BTN_Options()
        InitBeepOptions()
        If ComPortConnected Then OpenComm()
        EnabledDisableButtons()
        Timer1.Interval = 100
        Timer1.Start()
        InitTestingType()
        EventsAreEnabled = True
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Save_INI()
        COM_Close()
    End Sub

    Private Sub Form1_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move
        LimitFormPosition(Me)
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Me.Width > GRB_Tester.Width + 40 Then
            EnlargedWidth = Me.Width
        End If
    End Sub

    ' =========================================================================
    '  OPEN CLOSE - COMM PORT OPTIONS
    ' =========================================================================
    Private Sub Update_BTN_Options()
        If Me.Width > GRB_Tester.Width + 40 Then
            BTN_Options.BackColor = Color.FromArgb(255, 200, 100)
            GRB_StringToSend.Visible = True
            GRB_SerialPort.Visible = True
            GRB_SendString.Visible = True
        Else
            BTN_Options.BackColor = Color.FromArgb(240, 240, 240)
            GRB_StringToSend.Visible = False
            GRB_SerialPort.Visible = False
            GRB_SendString.Visible = False
            COM_DiscardInBuffer()
        End If
        SetMinimumSize()
    End Sub

    Private Sub BTN_Options_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_Options.Click
        Me.MinimumSize = New Size(0, Me.MinimumSize.Height)
        Me.MaximumSize = New Size(9999, 9999)
        If Me.Width > GRB_Tester.Width + 40 Then
            Me.Width = GRB_Tester.Width + 30
        Else
            Me.Width = EnlargedWidth
        End If
        Update_BTN_Options()
    End Sub

    Private Sub SetMinimumSize()
        If Me.Width < GRB_Tester.Width + 40 Then
            Me.MinimumSize = New Size(GRB_Tester.Width + 30, Me.MinimumSize.Height)
            Me.MaximumSize = New Size(GRB_Tester.Width + 30, 9999)
        Else
            Me.MinimumSize = New Size(489, Me.MinimumSize.Height)
            Me.MaximumSize = New Size(489, 9999)
        End If
    End Sub


    ' =========================================================================
    '  COMM PORT OPTIONS
    ' =========================================================================
    Private Sub OpenComm()
        Dim baudrate As Int32 = CInt(Val(cmb_ComSpeed.Text))
        COM_Open(cmb_ComPort.Text, baudrate)
        UpdateComButton()
        COM_DiscardInBuffer()
        EnabledDisableButtons()
        RawRes = Single.MaxValue
    End Sub

    Friend Sub UpdateComButton()
        If COM_IsOpen() Then
            btn_Connect.Text = "Disconnect"
            btn_Connect.BackColor = Color.FromArgb(255, 180, 120)
        Else
            btn_Connect.Text = "Connect"
            btn_Connect.BackColor = Color.FromArgb(240, 240, 240)
        End If
        btn_Connect.Refresh()
    End Sub

    Private Sub btn_Connect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Connect.Click
        If COM_IsOpen() Then
            COM_Close()
            UpdateComButton()
        Else
            OpenComm()
        End If
    End Sub

    Private Sub cmb_ComPort_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ComPort.DropDown
        EventsAreEnabled = False
        ComboComPort_AddItems()
        EventsAreEnabled = True
    End Sub

    Private Sub ComboComPort_AddItems()
        Dim c As String = cmb_ComPort.Text
        cmb_ComPort.Items.Clear()
        For Each s As String In COM_GetPortNames()
            cmb_ComPort.Items.Add(s)
        Next
        cmb_ComPort.Text = c
    End Sub

    Private Sub cmb_ComPort_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ComPort.TextChanged
        If Not EventsAreEnabled Then Return
        OpenComm()
        InitTestingType()
    End Sub
    Private Sub cmb_ComPort_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ComPort.DropDownClosed
        btn_Connect.Focus()
    End Sub

    Private Sub cmb_ComSpeed_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cmb_ComSpeed.KeyDown
        OnlyNumericComboBox(sender, e)
    End Sub
    Private Sub cmb_ComSpeed_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ComSpeed.TextChanged
        If Not EventsAreEnabled Then Return
        OpenComm()
        InitTestingType()
    End Sub
    Private Sub cmb_ComSpeed_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_ComSpeed.DropDownClosed
        btn_Connect.Focus()
    End Sub

    ' =========================================================================
    '  BEEP OPTIONS
    ' =========================================================================
    Private Sub txt_Frequency_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Frequency.TextChanged
        InitBeepOptions()
        If Not EventsAreEnabled Then Return
        If Control.MouseButtons = Windows.Forms.MouseButtons.None Then Return
        StartBeep()
    End Sub
    Private Sub txt_Frequency_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_Frequency.MouseUp
        StopBeep()
    End Sub

    Private Sub txt_Volume_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Volume.TextChanged
        InitBeepOptions()
        If Not EventsAreEnabled Then Return
        If Control.MouseButtons = Windows.Forms.MouseButtons.None Then Return
        StartBeep()
    End Sub
    Private Sub txt_Volume_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_Volume.MouseUp
        StopBeep()
    End Sub

    Private Sub txt_BeepResistance_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_BeepResistance.TextChanged
        InitBeepOptions()
    End Sub

    Private Sub InitBeepOptions()
        SetBeepOptions(Me.txt_Frequency.NumericValueInteger, _
                       Me.txt_Volume.NumericValueInteger, _
                       Me.txt_BeepResistance.NumericValueInteger)
    End Sub

    ' ==============================================================================================================
    '   ToolTips
    ' ==============================================================================================================
    Private ttp1 As ToolTip
    Private Sub ToolTips_Init()
        ttp1 = New ToolTip
        ttp1.ShowAlways = True
        ttp1.UseAnimation = True
        ttp1.UseFading = True
        ttp1.IsBalloon = True
        ttp1.AutoPopDelay = 32700
        ttp1.InitialDelay = 700
        ttp1.ReshowDelay = 500
        ' --------------------------------------------------------------- Add here Controls and ToolTip-Text
        ttp1.SetToolTip(txt_SlotOutput, _
                        " Output slot" & vbCrLf & _
                        " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -" & vbCrLf & _
                        " The index of the text-slot to write tested values." & vbCrLf & vbCrLf & _
                        " Press the left mouse button and move mouse Up and Down" & vbCrLf & _
                        " or use the mouse wheel to trim this value." & vbCrLf & _
                        " Set this Slot to -1 to disable the Output Slot")

        ttp1.SetToolTip(txt_SlotCommands, _
                        " Commands slot" & vbCrLf & _
                        " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -" & vbCrLf & _
                        " The text slot to command tester operations." & vbCrLf & vbCrLf & _
                        " Press the left mouse button and move mouse Up and Down" & vbCrLf & _
                        " or use the mouse wheel to trim this value." & vbCrLf & _
                        " Set this Slot to -1 to disable the Commands Slot" & vbCrLf & vbCrLf & _
                        " Commands to send in the Text-Slot are:" & vbCrLf & _
                        "  Mode BEEP - For Low-Res and Beep" & vbCrLf & _
                        "  Mode TEST - To start the LCR and active components test")

        ttp1.SetToolTip(txt_Frequency, _
                        " The acoustic signal frequency" & vbCrLf & _
                        " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -" & vbCrLf & _
                        " Set this frequency as you prefer." & vbCrLf & _
                        " Maybe 1000 Hz is better audible and similar to the hardware beep.")

        ttp1.SetToolTip(txt_Volume, _
                        " The acoustic signal volume" & vbCrLf & _
                        " - - - - - - - - - - - - - - - - - - - - - - - - - - - - -" & vbCrLf & _
                        " Set this volume as you prefer." & vbCrLf & _
                        " Normally a confortable value could be -10")

        ttp1.SetToolTip(txt_BeepResistance, _
                        " Resistance for continuity test" & vbCrLf & _
                        " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -" & vbCrLf & _
                        " If the resistance between probes 1 and 2 is lower than this value," & vbCrLf & _
                        " continuity is detected and an acoustic signal is emitted.")
    End Sub
    ' --------------------- this corrects the XP bug that causes tooltip disappearing for ever 
    Private Sub controls_MouseEnter(ByVal sender As Object, _
                                   ByVal e As System.EventArgs) Handles txt_SlotOutput.MouseEnter, _
                                                                        txt_SlotCommands.MouseEnter
        ttp1.Active = False
        ttp1.Active = True
    End Sub


    ' =========================================================================
    '  RECEIVE TIMER
    ' =========================================================================
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        '
        Static TryToReconnect As Boolean = False
        If ArduinoIDE_HasFocus() Then
            If COM_IsOpen() Then
                ' -------------------------------------------------------- DISCONNECT IF ARDUINO IDE FOCUSED
                COM_Close()
                UpdateComButton()
                Console.Beep(880, 100)
                Console.Beep(440, 100)
                TryToReconnect = True
            End If
        Else
            ' ------------------------------------------------------------ RECONNECT 
            If TryToReconnect Then
                If Not COM_IsOpen() Then
                    OpenComm()
                    Threading.Thread.Sleep(100)
                    If COM_IsOpen() Then
                        TryToReconnect = False
                        Console.Beep(440, 100)
                        Console.Beep(880, 100)
                    End If
                End If
            End If
        End If
        '
        ' --------------------------------------------------------------------- show text
        Dim s As String = vbCrLf
        If COM_IsOpen() Then
            If TestingLowRes Then
                If RawRes < ContinuityResistance Then
                    s += "    CONTINUITY" + vbCrLf + "      DETECTED"
                    TXT_ReceivedText.BackColor = Color.FromArgb(255, 240, 200)
                ElseIf RawRes < Single.MaxValue Then
                    s += "Continuity test" + vbCrLf + "with probes 1 and 2"
                    TXT_ReceivedText.BackColor = Color.WhiteSmoke
                    '
                    s += vbCrLf + vbCrLf + Replace(Millivolt.ToString("0"), ",", ".") + " mV  "
                    If Resistance < 9000 Then
                        s += Replace(Resistance.ToString("0"), ",", ".") + " ohm"
                    Else
                        s += " >9000 ohm"
                    End If
                Else
                    s += "   No data received" + vbCrLf + " from the serial port."
                End If
            Else
                s += COM_ReceivedText
            End If
        Else
            s += "    The serial port" + vbCrLf + "   is disconnected."
        End If
        '
        ' --------------------------------------------------------------------- send to SlotOutput
        If txt_SlotOutput.NumericValueInteger >= 0 Then
            StringSlots.WriteString(txt_SlotOutput.NumericValueInteger, s.Replace(vbCrLf, "  "))
        End If
        '
        ' ---------------------------------------------------------------------
        If Not Me.WindowState = FormWindowState.Minimized Then
            ' ----------------------------------------------------------------- print values
            TXT_ReceivedText.Text = s
        End If
        '
        ' --------------------------------------------------------------------- test commands
        If txt_SlotCommands.NumericValueInteger >= 0 Then
            s = StringSlots.ReadString(txt_SlotCommands.NumericValueInteger).ToUpper
            If s.Contains("BEEP") Then
                ClearCommandSlot()
                BTN_BeepTester_Click(Nothing, Nothing)
            End If
            If s.Contains("TEST") Then
                ClearCommandSlot()
                BTN_TransistorTester_Click(Nothing, Nothing)
            End If
        End If
    End Sub

    Private Sub ClearCommandSlot()
        StringSlots.WriteString(txt_SlotCommands.NumericValueInteger, "")
    End Sub

    Private Sub EnabledDisableButtons()
        If COM_IsOpen() Then
            BTN_TransistorTester.Enabled = True
            BTN_BeepTester.Enabled = True
            InitTestingType()
        Else
            TXT_ReceivedText.Text = ""
            BTN_TransistorTester.Enabled = False
            BTN_BeepTester.Enabled = False
        End If
    End Sub


    ' =========================================================================
    '  TEST BUTTONS
    ' =========================================================================
    Private Sub BTN_TransistorTester_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_TransistorTester.Click
        If TestingComponentsFlag Then Return
        TestingLowRes = False
        InitTestingType()
    End Sub

    Private Sub BTN_BeepTester_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_BeepTester.Click
        TestingComponentsFlag = False
        TestingLowRes = True
        InitTestingType()
    End Sub

    Private Sub InitTestingType()
        TestFirmwareMode = False
        If TestingLowRes Then
            COM_SendText("1")
            BTN_TransistorTester.BackColor = Color.FromArgb(240, 240, 240)
            BTN_BeepTester.BackColor = Color.FromArgb(255, 200, 100)
        Else
            COM_SendText("2")
            COM_SendText("3")
            BTN_TransistorTester.BackColor = Color.FromArgb(255, 200, 100)
            BTN_BeepTester.BackColor = Color.FromArgb(240, 240, 240)
        End If
        For i As Int32 = 1 To 10
            COM_DiscardInBuffer()
            COM_ReceivedText = ""
            Threading.Thread.Sleep(10)
        Next
        If TestingLowRes Then
            GRB_Tester.Text = "Test for Low value resistors and BEEP"
        Else
            GRB_Tester.Text = "Test for LCR and active components"
        End If
        TestFirmwareMode = True
    End Sub

End Class
