﻿Module Module_Utils

    ' =======================================================================================================
    '   APP TITLE AND VERSION (ALL FIELDS)
    ' =======================================================================================================
    Friend Function AppTitleAndVersion(Optional ByVal RemoveThereminoPrefix As Boolean = False) As String
        Dim appname As String = IO.Path.GetFileNameWithoutExtension(Application.ExecutablePath)
        Dim Title As String = Replace(appname, "_", " ")
        If RemoveThereminoPrefix Then Title = Replace(Title, "Theremino ", "")
        Return Title + " - V" + GetVersionString()
    End Function

    ' =======================================================================================================
    '   GET VERSION (ALSO TRIPLE OR QUADRUPLE FIELDS)
    ' =======================================================================================================
    Friend Function GetVersionString() As String
        Dim s() As String = Split(My.Application.Info.Version.ToString, ".")
        GetVersionString = s(0) + "." + s(1)
        If s(2) <> "0" Then
            GetVersionString += "." + s(2)
            If s(3) <> "0" Then
                GetVersionString += "." + s(3)
            End If
        End If
    End Function


    ' =======================================================================================================
    '   CULTURE INFO FOR STRING CONVERSIONS
    ' =======================================================================================================
    Friend CultureInfo As Globalization.CultureInfo = Globalization.CultureInfo.InvariantCulture

    ' =======================================================================================================
    '   MIXED FUNCTIONS
    ' =======================================================================================================
    Friend Function ReplaceMultipleSpacesAndTabAndTrim(ByVal s As String) As String
        s = s.Replace(vbTab, " ")
        While s.Contains("  ")
            s = s.Replace("  ", " ")
        End While
        Return s.Trim
    End Function

    Friend Function CursorInsideControl(ByVal ctl As Control) As Boolean
        Return ctl.ClientRectangle.Contains(ctl.PointToClient(Cursor.Position))
    End Function


    ' =======================================================================================================
    '  ONLY Positive Integer NUMERIC COMBO BOX
    ' -------------------------------------------------------------------------------------------------------
    '  Call from KeyDown event with: OnlyNumericComboBox(sender, e)
    ' =======================================================================================================
    Friend Sub OnlyNumericComboBox(ByVal sender As Object, ByVal e As KeyEventArgs)
        ' ------------------------------------------------------ Allow navigation keyboard arrows
        Select Case e.KeyCode
            Case Keys.Up, Keys.Down, Keys.Left, Keys.Right, Keys.PageUp, Keys.PageDown, Keys.Delete
                e.SuppressKeyPress = False
                Return
        End Select
        ' ------------------------------------------------------ Block non-number characters
        Dim currentKey As Char = Chr(e.KeyCode)
        If Not My.Computer.Keyboard.CtrlKeyDown And _
           Not Char.IsControl(currentKey) And _
           Not Char.IsDigit(currentKey) And _
           Not e.KeyCode = Keys.OemMinus And _
           Not e.KeyCode = Keys.OemPeriod Then
            e.SuppressKeyPress = True
        End If
        ' -------------------------------------------------------- no decimal point
        If e.KeyCode = Keys.OemPeriod  Then
            e.SuppressKeyPress = True
        End If
        ' -------------------------------------------------------- no minus sign
        If e.KeyCode = Keys.OemMinus  Then
            e.SuppressKeyPress = True
        End If
        ' ------------------------------------------------------- Handle pasted Text
        If e.Control AndAlso e.KeyCode = Keys.V Then
            ' --------------------------------------------------- Preview paste data (removing non-number characters)
            Dim pasteText As String = Clipboard.GetText
            Dim strippedText As String = ""
            Dim i As Integer = 0
            Do While i < pasteText.Length
                If Char.IsDigit(pasteText(i)) Then
                    strippedText = strippedText + pasteText(i).ToString
                End If
                i = (i + 1)
            Loop
            ' --------------------------------------------------- If there were non-numbers in the pasted text
            If strippedText <> pasteText Then

                e.SuppressKeyPress = True
                ' ----------------------------------------------- OPTIONAL: Manually insert text stripped of non-numbers
                Dim tbox As ComboBox = CType(sender, ComboBox)
                Dim start As Integer = tbox.SelectionStart
                Dim newTxt As String = tbox.Text
                newTxt = newTxt.Remove(tbox.SelectionStart, tbox.SelectionLength)
                ' ----------------------------------------------- remove highlighted text
                newTxt = newTxt.Insert(tbox.SelectionStart, strippedText)
                ' ----------------------------------------------- paste
                tbox.Text = newTxt
                tbox.SelectionStart = start + strippedText.Length
            Else
                e.SuppressKeyPress = False
            End If
        End If
    End Sub

    ' =============================================================
    '    SmootValue Adaptive - Single version
    ' =============================================================
    Friend Sub SmoothValue_Pow_Adaptive(ByRef value As Single, ByVal new_value As Single, ByVal speed As Single)
        Dim delta As Single = new_value - value
        Dim delta_sgn As Single = Math.Sign(delta)
        Dim delta_abs As Single = Math.Abs(delta)
        Dim delta_pow As Single = CSng(delta_abs ^ 2) * speed
        If value <> 0 Then delta_pow /= Math.abs(value)
        If delta_pow >= delta_abs Then
            value = new_value
        Else
            value += delta_sgn * delta_pow
        End If
        ' ------------------ if not equal to itself then it is a NAN
        If value <> value Then value = 0
    End Sub

End Module
