﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lbl_Com = New System.Windows.Forms.Label
        Me.cmb_ComPort = New System.Windows.Forms.ComboBox
        Me.cmb_ComSpeed = New System.Windows.Forms.ComboBox
        Me.btn_Connect = New System.Windows.Forms.Button
        Me.lbl_Speed = New System.Windows.Forms.Label
        Me.GRB_StringToSend = New System.Windows.Forms.GroupBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txt_SlotCommands = New Theremino_Tester.MyTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txt_SlotOutput = New Theremino_Tester.MyTextBox
        Me.GRB_SendString = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txt_Volume = New Theremino_Tester.MyTextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txt_Frequency = New Theremino_Tester.MyTextBox
        Me.GRB_SerialPort = New System.Windows.Forms.GroupBox
        Me.BTN_Options = New System.Windows.Forms.Button
        Me.GRB_Tester = New System.Windows.Forms.GroupBox
        Me.TXT_ReceivedText = New System.Windows.Forms.TextBox
        Me.BTN_BeepTester = New System.Windows.Forms.Button
        Me.BTN_TransistorTester = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.txt_BeepResistance = New Theremino_Tester.MyTextBox
        Me.GRB_StringToSend.SuspendLayout()
        Me.GRB_SendString.SuspendLayout()
        Me.GRB_SerialPort.SuspendLayout()
        Me.GRB_Tester.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'lbl_Com
        '
        Me.lbl_Com.AutoSize = True
        Me.lbl_Com.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Com.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.lbl_Com.Location = New System.Drawing.Point(15, 22)
        Me.lbl_Com.Name = "lbl_Com"
        Me.lbl_Com.Size = New System.Drawing.Size(29, 15)
        Me.lbl_Com.TabIndex = 53
        Me.lbl_Com.Text = "Port"
        '
        'cmb_ComPort
        '
        Me.cmb_ComPort.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmb_ComPort.DropDownHeight = 450
        Me.cmb_ComPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_ComPort.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_ComPort.FormattingEnabled = True
        Me.cmb_ComPort.IntegralHeight = False
        Me.cmb_ComPort.Location = New System.Drawing.Point(61, 18)
        Me.cmb_ComPort.Name = "cmb_ComPort"
        Me.cmb_ComPort.Size = New System.Drawing.Size(77, 23)
        Me.cmb_ComPort.TabIndex = 54
        '
        'cmb_ComSpeed
        '
        Me.cmb_ComSpeed.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmb_ComSpeed.DropDownHeight = 450
        Me.cmb_ComSpeed.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_ComSpeed.FormattingEnabled = True
        Me.cmb_ComSpeed.IntegralHeight = False
        Me.cmb_ComSpeed.ItemHeight = 15
        Me.cmb_ComSpeed.Items.AddRange(New Object() {"600", "1200", "2400", "4800", "9600", "14400", "19200", "28800", "38400", "56000", "57600", "74880", "115200", "128000", "256000", "500000", "1000000"})
        Me.cmb_ComSpeed.Location = New System.Drawing.Point(61, 46)
        Me.cmb_ComSpeed.MaxLength = 7
        Me.cmb_ComSpeed.Name = "cmb_ComSpeed"
        Me.cmb_ComSpeed.Size = New System.Drawing.Size(77, 23)
        Me.cmb_ComSpeed.TabIndex = 55
        Me.cmb_ComSpeed.Text = "9600"
        '
        'btn_Connect
        '
        Me.btn_Connect.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Connect.BackColor = System.Drawing.Color.Gainsboro
        Me.btn_Connect.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Connect.ForeColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.btn_Connect.Location = New System.Drawing.Point(11, 75)
        Me.btn_Connect.Name = "btn_Connect"
        Me.btn_Connect.Size = New System.Drawing.Size(129, 27)
        Me.btn_Connect.TabIndex = 56
        Me.btn_Connect.Text = "Connect"
        Me.btn_Connect.UseVisualStyleBackColor = False
        '
        'lbl_Speed
        '
        Me.lbl_Speed.AutoSize = True
        Me.lbl_Speed.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Speed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.lbl_Speed.Location = New System.Drawing.Point(13, 50)
        Me.lbl_Speed.Name = "lbl_Speed"
        Me.lbl_Speed.Size = New System.Drawing.Size(43, 15)
        Me.lbl_Speed.TabIndex = 57
        Me.lbl_Speed.Text = "Speed"
        '
        'GRB_StringToSend
        '
        Me.GRB_StringToSend.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GRB_StringToSend.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.GRB_StringToSend.Controls.Add(Me.Label4)
        Me.GRB_StringToSend.Controls.Add(Me.txt_SlotCommands)
        Me.GRB_StringToSend.Controls.Add(Me.Label1)
        Me.GRB_StringToSend.Controls.Add(Me.txt_SlotOutput)
        Me.GRB_StringToSend.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GRB_StringToSend.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GRB_StringToSend.Location = New System.Drawing.Point(316, 123)
        Me.GRB_StringToSend.Name = "GRB_StringToSend"
        Me.GRB_StringToSend.Size = New System.Drawing.Size(148, 63)
        Me.GRB_StringToSend.TabIndex = 60
        Me.GRB_StringToSend.TabStop = False
        Me.GRB_StringToSend.Text = "Text Slots"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(11, 40)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 15)
        Me.Label4.TabIndex = 60
        Me.Label4.Text = "Commands"
        '
        'txt_SlotCommands
        '
        Me.txt_SlotCommands.ArrowsIncrement = 1
        Me.txt_SlotCommands.BackColor = System.Drawing.Color.MintCream
        Me.txt_SlotCommands.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotCommands.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotCommands.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_SlotCommands.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotCommands.ForeColor = System.Drawing.Color.Black
        Me.txt_SlotCommands.Increment = 0.2
        Me.txt_SlotCommands.Location = New System.Drawing.Point(91, 39)
        Me.txt_SlotCommands.MaxValue = 999
        Me.txt_SlotCommands.MinValue = -1
        Me.txt_SlotCommands.Name = "txt_SlotCommands"
        Me.txt_SlotCommands.NumericValue = -1
        Me.txt_SlotCommands.NumericValueInteger = -1
        Me.txt_SlotCommands.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotCommands.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotCommands.RoundingStep = 0
        Me.txt_SlotCommands.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotCommands.Size = New System.Drawing.Size(47, 15)
        Me.txt_SlotCommands.SuppressZeros = True
        Me.txt_SlotCommands.TabIndex = 59
        Me.txt_SlotCommands.Text = "-1"
        Me.txt_SlotCommands.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(11, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 15)
        Me.Label1.TabIndex = 58
        Me.Label1.Text = "Output"
        '
        'txt_SlotOutput
        '
        Me.txt_SlotOutput.ArrowsIncrement = 1
        Me.txt_SlotOutput.BackColor = System.Drawing.Color.MintCream
        Me.txt_SlotOutput.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotOutput.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotOutput.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_SlotOutput.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotOutput.ForeColor = System.Drawing.Color.Black
        Me.txt_SlotOutput.Increment = 0.2
        Me.txt_SlotOutput.Location = New System.Drawing.Point(91, 19)
        Me.txt_SlotOutput.MaxValue = 999
        Me.txt_SlotOutput.MinValue = -1
        Me.txt_SlotOutput.Name = "txt_SlotOutput"
        Me.txt_SlotOutput.NumericValue = -1
        Me.txt_SlotOutput.NumericValueInteger = -1
        Me.txt_SlotOutput.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotOutput.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotOutput.RoundingStep = 0
        Me.txt_SlotOutput.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotOutput.Size = New System.Drawing.Size(47, 15)
        Me.txt_SlotOutput.SuppressZeros = True
        Me.txt_SlotOutput.TabIndex = 11
        Me.txt_SlotOutput.Text = "-1"
        Me.txt_SlotOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GRB_SendString
        '
        Me.GRB_SendString.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GRB_SendString.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.GRB_SendString.Controls.Add(Me.Label5)
        Me.GRB_SendString.Controls.Add(Me.txt_BeepResistance)
        Me.GRB_SendString.Controls.Add(Me.Label3)
        Me.GRB_SendString.Controls.Add(Me.txt_Volume)
        Me.GRB_SendString.Controls.Add(Me.Label2)
        Me.GRB_SendString.Controls.Add(Me.txt_Frequency)
        Me.GRB_SendString.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GRB_SendString.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GRB_SendString.Location = New System.Drawing.Point(316, 192)
        Me.GRB_SendString.Name = "GRB_SendString"
        Me.GRB_SendString.Size = New System.Drawing.Size(148, 83)
        Me.GRB_SendString.TabIndex = 66
        Me.GRB_SendString.TabStop = False
        Me.GRB_SendString.Text = "Beep parameters"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(10, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 15)
        Me.Label3.TabIndex = 63
        Me.Label3.Text = "Volume (dB)"
        '
        'txt_Volume
        '
        Me.txt_Volume.ArrowsIncrement = 1
        Me.txt_Volume.BackColor = System.Drawing.Color.MintCream
        Me.txt_Volume.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Volume.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Volume.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Volume.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Volume.ForeColor = System.Drawing.Color.Black
        Me.txt_Volume.Increment = 0.2
        Me.txt_Volume.Location = New System.Drawing.Point(93, 40)
        Me.txt_Volume.MaxValue = 0
        Me.txt_Volume.MinValue = -99
        Me.txt_Volume.Name = "txt_Volume"
        Me.txt_Volume.NumericValue = -10
        Me.txt_Volume.NumericValueInteger = -10
        Me.txt_Volume.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Volume.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Volume.RoundingStep = 0
        Me.txt_Volume.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Volume.Size = New System.Drawing.Size(45, 15)
        Me.txt_Volume.SuppressZeros = True
        Me.txt_Volume.TabIndex = 62
        Me.txt_Volume.Text = "-10"
        Me.txt_Volume.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(11, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 15)
        Me.Label2.TabIndex = 61
        Me.Label2.Text = "Frequency"
        '
        'txt_Frequency
        '
        Me.txt_Frequency.ArrowsIncrement = 1
        Me.txt_Frequency.BackColor = System.Drawing.Color.MintCream
        Me.txt_Frequency.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Frequency.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Frequency.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Frequency.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Frequency.ForeColor = System.Drawing.Color.Black
        Me.txt_Frequency.Increment = 0.2
        Me.txt_Frequency.Location = New System.Drawing.Point(93, 20)
        Me.txt_Frequency.MaxValue = 20000
        Me.txt_Frequency.MinValue = 1
        Me.txt_Frequency.Name = "txt_Frequency"
        Me.txt_Frequency.NumericValue = 1000
        Me.txt_Frequency.NumericValueInteger = 1000
        Me.txt_Frequency.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Frequency.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Frequency.RoundingStep = 0
        Me.txt_Frequency.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Frequency.Size = New System.Drawing.Size(45, 15)
        Me.txt_Frequency.SuppressZeros = True
        Me.txt_Frequency.TabIndex = 60
        Me.txt_Frequency.Text = "1000"
        Me.txt_Frequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GRB_SerialPort
        '
        Me.GRB_SerialPort.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GRB_SerialPort.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GRB_SerialPort.Controls.Add(Me.btn_Connect)
        Me.GRB_SerialPort.Controls.Add(Me.cmb_ComSpeed)
        Me.GRB_SerialPort.Controls.Add(Me.lbl_Speed)
        Me.GRB_SerialPort.Controls.Add(Me.cmb_ComPort)
        Me.GRB_SerialPort.Controls.Add(Me.lbl_Com)
        Me.GRB_SerialPort.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GRB_SerialPort.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GRB_SerialPort.Location = New System.Drawing.Point(316, 7)
        Me.GRB_SerialPort.Name = "GRB_SerialPort"
        Me.GRB_SerialPort.Size = New System.Drawing.Size(148, 109)
        Me.GRB_SerialPort.TabIndex = 67
        Me.GRB_SerialPort.TabStop = False
        Me.GRB_SerialPort.Text = "Serial port"
        '
        'BTN_Options
        '
        Me.BTN_Options.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BTN_Options.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BTN_Options.BackgroundImage = CType(resources.GetObject("BTN_Options.BackgroundImage"), System.Drawing.Image)
        Me.BTN_Options.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.BTN_Options.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTN_Options.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTN_Options.ForeColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BTN_Options.Location = New System.Drawing.Point(215, 240)
        Me.BTN_Options.Name = "BTN_Options"
        Me.BTN_Options.Size = New System.Drawing.Size(93, 35)
        Me.BTN_Options.TabIndex = 57
        Me.BTN_Options.UseVisualStyleBackColor = False
        '
        'GRB_Tester
        '
        Me.GRB_Tester.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GRB_Tester.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.GRB_Tester.Controls.Add(Me.TXT_ReceivedText)
        Me.GRB_Tester.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GRB_Tester.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.GRB_Tester.Location = New System.Drawing.Point(8, 7)
        Me.GRB_Tester.Name = "GRB_Tester"
        Me.GRB_Tester.Size = New System.Drawing.Size(299, 226)
        Me.GRB_Tester.TabIndex = 69
        Me.GRB_Tester.TabStop = False
        Me.GRB_Tester.Text = "Test for Low value resistors and BEEP"
        '
        'TXT_ReceivedText
        '
        Me.TXT_ReceivedText.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TXT_ReceivedText.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TXT_ReceivedText.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXT_ReceivedText.HideSelection = False
        Me.TXT_ReceivedText.Location = New System.Drawing.Point(13, 23)
        Me.TXT_ReceivedText.Multiline = True
        Me.TXT_ReceivedText.Name = "TXT_ReceivedText"
        Me.TXT_ReceivedText.ReadOnly = True
        Me.TXT_ReceivedText.Size = New System.Drawing.Size(276, 192)
        Me.TXT_ReceivedText.TabIndex = 51
        Me.TXT_ReceivedText.WordWrap = False
        '
        'BTN_BeepTester
        '
        Me.BTN_BeepTester.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BTN_BeepTester.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BTN_BeepTester.BackgroundImage = CType(resources.GetObject("BTN_BeepTester.BackgroundImage"), System.Drawing.Image)
        Me.BTN_BeepTester.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.BTN_BeepTester.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTN_BeepTester.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTN_BeepTester.ForeColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BTN_BeepTester.Location = New System.Drawing.Point(112, 240)
        Me.BTN_BeepTester.Name = "BTN_BeepTester"
        Me.BTN_BeepTester.Size = New System.Drawing.Size(93, 35)
        Me.BTN_BeepTester.TabIndex = 70
        Me.BTN_BeepTester.UseVisualStyleBackColor = False
        '
        'BTN_TransistorTester
        '
        Me.BTN_TransistorTester.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BTN_TransistorTester.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BTN_TransistorTester.BackgroundImage = CType(resources.GetObject("BTN_TransistorTester.BackgroundImage"), System.Drawing.Image)
        Me.BTN_TransistorTester.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.BTN_TransistorTester.Enabled = False
        Me.BTN_TransistorTester.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTN_TransistorTester.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTN_TransistorTester.ForeColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BTN_TransistorTester.Location = New System.Drawing.Point(9, 240)
        Me.BTN_TransistorTester.Name = "BTN_TransistorTester"
        Me.BTN_TransistorTester.Size = New System.Drawing.Size(93, 35)
        Me.BTN_TransistorTester.TabIndex = 71
        Me.BTN_TransistorTester.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(10, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 15)
        Me.Label5.TabIndex = 65
        Me.Label5.Text = "Res.   (ohm)"
        '
        'txt_BeepResistance
        '
        Me.txt_BeepResistance.ArrowsIncrement = 1
        Me.txt_BeepResistance.BackColor = System.Drawing.Color.MintCream
        Me.txt_BeepResistance.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_BeepResistance.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_BeepResistance.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_BeepResistance.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BeepResistance.ForeColor = System.Drawing.Color.Black
        Me.txt_BeepResistance.Increment = 0.2
        Me.txt_BeepResistance.Location = New System.Drawing.Point(93, 60)
        Me.txt_BeepResistance.MaxValue = 99
        Me.txt_BeepResistance.MinValue = 1
        Me.txt_BeepResistance.Name = "txt_BeepResistance"
        Me.txt_BeepResistance.NumericValue = 2
        Me.txt_BeepResistance.NumericValueInteger = 2
        Me.txt_BeepResistance.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_BeepResistance.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_BeepResistance.RoundingStep = 0
        Me.txt_BeepResistance.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_BeepResistance.Size = New System.Drawing.Size(45, 15)
        Me.txt_BeepResistance.SuppressZeros = True
        Me.txt_BeepResistance.TabIndex = 64
        Me.txt_BeepResistance.Text = "2"
        Me.txt_BeepResistance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(473, 279)
        Me.Controls.Add(Me.BTN_TransistorTester)
        Me.Controls.Add(Me.BTN_BeepTester)
        Me.Controls.Add(Me.GRB_Tester)
        Me.Controls.Add(Me.BTN_Options)
        Me.Controls.Add(Me.GRB_SerialPort)
        Me.Controls.Add(Me.GRB_SendString)
        Me.Controls.Add(Me.GRB_StringToSend)
        Me.ForeColor = System.Drawing.Color.Black
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MinimumSize = New System.Drawing.Size(466, 318)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Tester"
        Me.GRB_StringToSend.ResumeLayout(False)
        Me.GRB_StringToSend.PerformLayout()
        Me.GRB_SendString.ResumeLayout(False)
        Me.GRB_SendString.PerformLayout()
        Me.GRB_SerialPort.ResumeLayout(False)
        Me.GRB_SerialPort.PerformLayout()
        Me.GRB_Tester.ResumeLayout(False)
        Me.GRB_Tester.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txt_SlotOutput As MyTextBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents lbl_Com As System.Windows.Forms.Label
    Friend WithEvents cmb_ComPort As System.Windows.Forms.ComboBox
    Friend WithEvents cmb_ComSpeed As System.Windows.Forms.ComboBox
    Friend WithEvents btn_Connect As System.Windows.Forms.Button
    Friend WithEvents lbl_Speed As System.Windows.Forms.Label
    Friend WithEvents GRB_StringToSend As System.Windows.Forms.GroupBox
    Friend WithEvents GRB_SendString As System.Windows.Forms.GroupBox
    Friend WithEvents GRB_SerialPort As System.Windows.Forms.GroupBox
    Friend WithEvents BTN_Options As System.Windows.Forms.Button
    Friend WithEvents GRB_Tester As System.Windows.Forms.GroupBox
    Friend WithEvents TXT_ReceivedText As System.Windows.Forms.TextBox
    Friend WithEvents BTN_BeepTester As System.Windows.Forms.Button
    Friend WithEvents BTN_TransistorTester As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_Frequency As Theremino_Tester.MyTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_SlotCommands As Theremino_Tester.MyTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_Volume As Theremino_Tester.MyTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txt_BeepResistance As Theremino_Tester.MyTextBox

End Class
