﻿
Imports System.IO.Ports
Imports System.Text

Module Module_COM

    Friend Terminator1 As Int32 = -1
    Friend Terminator2 As Int32 = -1

    Private WithEvents ComPort As New SerialPort()

    Friend Sub COM_Open(ByVal PortName As String, ByVal BaudRate As Int32)
        If PortName = "" Then PortName = "COM1"
        If BaudRate < 600 Then BaudRate = 600
        ' -------------------------------------------- If the port is Open then close it
        COM_Close()
        ComPort.PortName = PortName
        ComPort.BaudRate = BaudRate
        ComPort.Parity = Parity.None
        ComPort.DataBits = 8
        ComPort.StopBits = StopBits.One
        ' -------------------------------------------- Set params
        ComPort.ReceivedBytesThreshold = 1
        ComPort.WriteTimeout = 500
        ComPort.ReadTimeout = 500
        ' -------------------------------------------- minimum serial buffer is about 65536
        ' ComPort.ReadBufferSize = 4096
        ' ReadBufferSize default is 4096
        ' ReadBufferSize ignores values less than 4096
        ' The ReadBufferSize is the Windows buffer only, 
        ' The BytesToRead property is: SerialPort buffer + Windows buffer (65536 total)
        '
        ' -------------------------------------------- separator used by "ReadLine" and "WriteLine" (default is LF)
        ComPort.NewLine = vbLf
        ' -------------------------------------------- 
        ComPort.DtrEnable = False
        ComPort.RtsEnable = False
        ' TODO - Sometimes this could be needed ? 
        'ComPort.DtrEnable = True
        'ComPort.RtsEnable = True
        ' --------------------------------------------
        Try
            ComPort.Open()
        Catch
        End Try
        ' --------------------------------------------
        COM_RemoveAllBytesToRead()
    End Sub

    Friend Sub COM_Close()
        If ComPort.IsOpen Then
            ComPort.Close()
        End If
    End Sub

    Friend Function COM_GetPortNames() As String()
        If SerialPort.GetPortNames().Length = 0 Then Return New String() {"No ports"}
        Return SerialPort.GetPortNames()
    End Function


    ' ==============================================================================
    '   COM SEND
    ' ==============================================================================
    Friend Sub COM_SendText(ByVal text As String)
        If Not ComPort.IsOpen Then Return
        Try
            ComPort.WriteLine(text)
        Catch
        End Try
    End Sub

    'Friend Sub COM_SendString(ByVal text As String, _
    '                          Optional ByVal terminator As Int32 = 0)
    '    If Not ComPort.IsOpen Then Return
    '    If terminator = 1 Then text += vbCr
    '    If terminator = 2 Then text += vbLf
    '    If terminator = 3 Then text += vbCrLf
    '    ComPort.Write(text)
    'End Sub

    ' ==============================================================================
    '   COM FUNCTIONS
    ' ==============================================================================
    Friend Function COM_IsOpen() As Boolean
        Return ComPort.IsOpen
    End Function

    Friend Sub COM_DiscardInBuffer()
        If ComPort.IsOpen Then
            ComPort.DiscardInBuffer()
        End If
    End Sub

    Friend Sub COM_RemoveAllBytesToRead()
        If ComPort.IsOpen Then
            While ComPort.BytesToRead > 1
                COM_DiscardInBuffer()
                Threading.Thread.Sleep(1)
            End While
            Debug.Print(ComPort.BytesToRead.ToString)
        End If
        COM_ReceivedText = ""
    End Sub


    ' ==============================================================================
    '   DATA RECEIVED EVENT
    ' ==============================================================================
    Private sw As New Stopwatch
    Friend COM_ReceivedText As String
    Friend TestFirmwareMode As Boolean = True
    Friend TestingComponentsFlag As Boolean = False

    Private Sub comPort_DataReceived(ByVal sender As Object, _
                                     ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) _
                                     Handles ComPort.DataReceived
        Try
            While ComPort.BytesToRead > 0
                '
                COM_ReceivedText += ChrW(ComPort.ReadChar)
                '
                If TestingLowRes Then
                    If COM_ReceivedText.EndsWith(vbLf) Then
                        DecodeAndBeep()
                        COM_ReceivedText = ""
                        COM_DiscardInBuffer()
                        ' -------------------------------------------------- DEBUG MILLISECONDS
                        'Debug.Print(sw.ElapsedMilliseconds.ToString)
                        'sw.Reset()
                        'sw.Start()
                    End If
                Else
                    If COM_ReceivedText.EndsWith("Testing") Then
                        COM_ReceivedText = "Testing components"
                        TestingComponentsFlag = True
                    End If
                    If COM_ReceivedText.EndsWith("Testing components..." + vbCrLf) Then
                        COM_ReceivedText = ""
                        TestingComponentsFlag = False
                    End If
                    StopBeep()
                End If
            End While
        Catch
        End Try
    End Sub


    ' ==============================================================================
    '  Decode and beep
    ' ==============================================================================
    Private Fields As String()
    Friend RawRes As Single = Single.MaxValue
    Friend RawMillivolt As Single
    Friend Resistance As Single
    Friend Millivolt As Single
    Friend ContinuityResistance As Single = 2
    Friend TestingLowRes As Boolean = True

    Private Sub DecodeAndBeep()
        If TestingLowRes Then
            Fields = COM_ReceivedText.Split(" "c)
            If Fields.Length <> 2 Then Return
            ' --------------------------------------------------- decode resistance value
            RawRes = CSng(Val(Fields(0))) / 1000
            SmoothValue_Pow_Adaptive(Resistance, RawRes, 10)
            ' --------------------------------------------------- decode millivolt value
            RawMillivolt = CSng(Val(Fields(1)))
            SmoothValue_Pow_Adaptive(Millivolt, RawMillivolt, 20)
            ' --------------------------------------------------- play beep
            Static PlayingBeep As Boolean = False
            If RawRes < ContinuityResistance Then
                If Not PlayingBeep Then
                    PlayingBeep = True
                    StartBeep()
                End If
            Else
                If PlayingBeep Then
                    PlayingBeep = False
                    wp1.PlayStop()
                End If
            End If
        End If
    End Sub

    ' ==============================================================================
    '  Beep player
    ' ==============================================================================
    Private wp1 As WavePlayer = New WavePlayer

    Friend Sub StartBeep()
        wp1.PlayStart(0)
    End Sub

    Friend Sub StopBeep()
        wp1.PlayStop()
    End Sub

    Friend Sub SetBeepOptions(ByVal frequency As Int32, ByVal db As Int32, ByVal BeepRes As Int32)
        wp1.SetFrequency(frequency)
        wp1.SetOutLevel(db)
        wp1.SetWaveType(WavePlayer.WaveTypes.Sine)
        ContinuityResistance = BeepRes + 0.5F
    End Sub

End Module


